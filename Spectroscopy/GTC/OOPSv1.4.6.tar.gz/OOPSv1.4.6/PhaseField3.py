#Compute change of wavelength 
#JIGS & AE 2013
import os
import sys
import pyfits
import numpy
from math import *

#command line arguments:
# 1: output file
# 2: TF etalon
# 3: central wavelength
# 4: bin
# 5: CCD

print len(sys.argv)

if len(sys.argv)<5:
	sys.exit("""
This program takes exactly 5 arguments:

 1: output file
 2: TF etalon ("TFRed")
 3: central wavelength (in Angstrom)
 4: bin (1 or 2)
 5: CCD (1 or 2)
	""")

def a(x,a0,a1,a2):
  a=a0+a1*x+a2*x*x
  return a

itf=sys.argv[2]
c0lambda=float(sys.argv[3])
bin=float(sys.argv[4])
ccd=float(sys.argv[5])

if itf == "TFRed":
	print "computing for Red TF"
elif itf == "TFBlue":
	print "computing for Blue TF"
else:
	sys.exit("sorry only TFRed and TFBlue are valid values")

pixsize=0.12718
nx=1000
ny=2000
if ccd == 1 :
	#optical centre wrt CCD1
	x_opt=1000.0
	y_opt=976.0
elif ccd == 2:
	#optical centre wrt CCD2
	x_opt=-11.0
	y_opt=976.0
else:
	sys.exit("Not valid value for CCD")

#process TF:
if (itf=="TFBlue") and (c0lambda < 3700 or c0lambda >6700):
    print 'Wavelength out of range. Change TF.'
    sys.exit()

if (itf=="TFRed") and (c0lambda < 6510 or c0lambda >9363):
    print 'Wavelength out of range. Change TF.'
    sys.exit()

if itf=="TFBlue":
    
    sys.exit("sorry, blue TF is not supporte yet")


if itf=="TFRed":
    c=5.04
    a0=6.17808
    a1=-1.6024E-3
    a2=1.0215E-7


#create image
file=sys.argv[1]
print file[-5:]
if not file[-5:] == ".fits":
	fileo=file+'.fits'
else:
	fileo=file
if os.path.exists(fileo):
	os.system('rm -v ' + fileo)
z=[]

#run through image and compute phase effect
#for each pixel a computation must be done as the
#transmitted wavelength is different

print("computing phase effect, pixel-per-pixel...")

tol=0.1

for j in range(1,ny+1):
    for i in range(1,nx+1):
        xp=float(i)
        yp=float(j)
        theta=sqrt((x_opt-xp)**2+(y_opt-yp)**2)*pixsize*bin/60.
        lambda_i=c0lambda-c*theta*theta
        diff=30.
        while (diff>tol):
           rlambda=c0lambda-c*theta*theta+a(lambda_i,a0,a1,a2)*pow(theta,3)
           diff=abs(rlambda-lambda_i)
           lambda_i=rlambda
        z.append(rlambda)
        
az=numpy.array(z)
b=numpy.reshape(az,(ny,nx))

print("... done")

print("creating image...")

hdu=pyfits.PrimaryHDU(b)
hdulist=pyfits.HDUList([hdu])
prihdr=hdulist[0].header
prihdr.update('OBJECT','FIELD_PHASE','FRAME NAME')

hdulist.writeto(fileo)

print("... done")
