import string

f = open("Curves.dat","r")
telOsiSens = open("telOsiSens.dat","w")
ORMext = open("ORMext.dat","w")
for eachLine in f:
	if not eachLine[0] == "#":
		eachItem = string.split(string.strip(eachLine))
		myString = eachItem[0] + " " + eachItem[2]
		telOsiSens.write(myString + "\n")
		myString = eachItem[0] + " " + eachItem[3]
		ORMext.write(myString + "\n")
ORMext.close()
telOsiSens.close()
f.close()
