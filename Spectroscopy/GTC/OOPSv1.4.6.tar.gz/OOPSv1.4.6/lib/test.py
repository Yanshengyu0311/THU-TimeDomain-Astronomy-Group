import string

zeropointsFile = open('zeropoints.dat','r')
for eachLine in zeropointsFile :
	print len(eachLine)
	if len(eachLine) > 1:
		eachItem = string.split(string.strip(eachLine))
		print eachItem,eachItem[0]
zeropointsFile.close()
