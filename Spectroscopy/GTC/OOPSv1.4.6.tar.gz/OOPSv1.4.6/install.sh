which python > tmp.py
sed 's/^/#!/' < tmp.py > OOPS.py
more OOPS.txt >> OOPS.py
chmod a+x OOPS.py
rm OOPS.txt
echo "done installing OOPS"

rm tmp.py
